/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Task3_AddToCartItemPage {

    public static void main(String[] args) {
       
        // Initialize WebDriver and WebDriverWait
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Perform login
            login(driver, wait, "standard_user", "secret_sauce");

            // Navigate to "Sauce Labs Onesie" details page
            wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Sauce Labs Onesie")));
            Thread.sleep(1*3000);
            WebElement onesieLink = driver.findElement(By.linkText("Sauce Labs Onesie"));
            onesieLink.click();

            // Add "Sauce Labs Onesie" to the cart
        
            wait.until(ExpectedConditions.elementToBeClickable(By.id("add-to-cart-sauce-labs-onesie")));
            Thread.sleep(1*3000);
            WebElement addToCartButton = driver.findElement(By.id("add-to-cart-sauce-labs-onesie"));
            addToCartButton.click();

            // Verify the cart count updates to 3
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("shopping_cart_badge")));
            Thread.sleep(1*3000);
            WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
            String cartCount = cartBadge.getText();
            System.out.println("Cart count: " + cartCount);

            // Validate cart count is 3
            if (cartCount.equals("3")) {
                System.out.println("Cart contains 3 items. Test passed.");
            } else {
                System.err.println("Cart count is incorrect. Expected: 3, Found: " + cartCount);
            }

        } catch (Exception e) {
            System.err.println("Test failed due to an exception: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Clean up and close the browser
            try {
                Thread.sleep(1*3000); // Optional delay to observe results
                driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

   
    public static void login(WebDriver driver, WebDriverWait wait, String username, String password) {
        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();

        // Enter username
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("user-name")));
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys(username);

        // Enter password
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password")));
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(password);

        // Click login button
        wait.until(ExpectedConditions.elementToBeClickable(By.id("login-button")));
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Verify redirection to inventory page
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
        System.out.println("Login successful.");
    }
}


