/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;

/**
 *
 * @author HP
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Task2_AddToCardInventory {
    public static void main(String[] args) {
      
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://www.saucedemo.com/");
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            // Sort items by Price (low to high)
            Thread.sleep(1*3000);
            Select sortDropdown = new Select(driver.findElement(By.className("product_sort_container")));
            sortDropdown.selectByValue("lohi");

            // Add items to cart
            driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
            driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();

            // Verify cart count
            WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
            assert cartBadge.getText().equals("2");
            System.out.println("Cart contains 2 items.");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
            finally {
            try {
                Thread.sleep(1*5000);
            driver.quit();
            } 
            catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
}
