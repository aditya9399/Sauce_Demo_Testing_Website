/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;

/**
 *
 * @author HP
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task6_LogoutFunctionality {
    public static void main(String[] args) {
        //System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        WebDriver driver = new ChromeDriver();

        try {
            Thread.sleep(1*3000);
            SauceDemoUtils.login(driver, "standard_user", "secret_sauce");

            // Logout
             Thread.sleep(1*3000);
            driver.findElement(By.id("react-burger-menu-btn")).click();
            driver.findElement(By.id("logout_sidebar_link")).click();

            // Verify redirection to login page
            //Thread.sleep(1*3000);
            String currentUrl = driver.getCurrentUrl();
            assert currentUrl.equals("https://www.saucedemo.com/");
            System.out.println("Successfully logged out.");
            
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
            driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

