/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;

/**
 *
 * @author HP
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task1_LoginValidation {
    public static void main(String[] args) {
        
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://www.saucedemo.com/");
            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();

            // Validation
            if (driver.getCurrentUrl().contains("/inventory.html")) {
                System.out.println("Login successful: Redirected to inventory page.");
            } else {
                WebElement error = driver.findElement(By.className("error-message-container"));
                System.out.println("Epic sadface username and password do not match any user in the service " + error.getText());
            }
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
            
            finally {
            try {
            Thread.sleep(1*4000);
            driver.quit();
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }

    }
}
