/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class Task4_RemoveItem {
    public static void main(String[] args) {
        // Set up WebDriver and WebDriverWait
        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        try {
            // Navigate to SauceDemo login page
            driver.get("https://www.saucedemo.com/");

            // Login with valid credentials
 
            wait.until(ExpectedConditions.elementToBeClickable(By.id("user-name"))).sendKeys("standard_user");
            wait.until(ExpectedConditions.elementToBeClickable(By.id("password"))).sendKeys("secret_sauce");
            wait.until(ExpectedConditions.elementToBeClickable(By.id("login-button"))).click();

            // Navigate to the cart
            wait.until(ExpectedConditions.elementToBeClickable(By.className("shopping_cart_link"))).click();

            // Find items in the cart and remove one costing between $8 and $10
            List<WebElement> cartItems = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className("cart_item")));
            boolean itemRemoved = false;

            for (WebElement item : cartItems) {
                String priceText = item.findElement(By.className("inventory_item_price")).getText();
                double price = Double.parseDouble(priceText.replace("$", ""));
                if (price >= 8 && price <= 10) {
                    item.findElement(By.className("cart_button")).click();
                    itemRemoved = true;
                    break;
                }
            }

            // Verify if an item was removed
            if (!itemRemoved) {
                System.out.println("No item found in the price range of $8 to $10.");
                return;
            }

            // Validate cart count
            WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
            String cartCount = cartBadge.getText();
            System.out.println("Cart count after removal: " + cartCount);

            if (cartCount.equals("2")) {
                System.out.println("Cart contains 2 items. Test passed.");
            } else {
                System.err.println("Test failed: Expected cart count is 2, but found " + cartCount);
            }
        } catch (Exception e) {
            System.err.println("Test failed: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close the browser
            try {
                Thread.sleep(1*3000);
            driver.quit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

