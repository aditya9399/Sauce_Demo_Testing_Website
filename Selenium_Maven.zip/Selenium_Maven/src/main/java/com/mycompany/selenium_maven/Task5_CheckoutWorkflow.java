/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.selenium_maven;

/**
 *
 * @author HP
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Task5_CheckoutWorkflow {
    public static void main(String[] args) {
       // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        WebDriver driver = new ChromeDriver();

        try {
            
            SauceDemoUtils.login(driver, "standard_user", "secret_sauce");

            // Proceed to checkout
            Thread.sleep(1*3000);
            driver.findElement(By.className("shopping_cart_link")).click();
            driver.findElement(By.id("checkout")).click();

            // Fill in checkout form
            Thread.sleep(1*3000);
            driver.findElement(By.id("first-name")).sendKeys("John");
            driver.findElement(By.id("last-name")).sendKeys("Doe");
            driver.findElement(By.id("postal-code")).sendKeys("12345");
            driver.findElement(By.id("continue")).click();

            // Verify items and print total amount
            Thread.sleep(1*3000);
            WebElement totalAmount = driver.findElement(By.className("summary_total_label"));
            System.out.println("Total Amount: " + totalAmount.getText());

            // Complete purchase
            driver.findElement(By.id("finish")).click();

            // Validate success message
            Thread.sleep(1*3000);
            WebElement thankYouMessage = driver.findElement(By.className("complete-header"));
            assert thankYouMessage.getText().equals("THANK YOU FOR YOUR ORDER");
            System.out.println("Checkout completed successfully.");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
            driver.quit();
            Thread.sleep(1*3000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
